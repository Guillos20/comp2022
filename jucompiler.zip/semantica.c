#include "struct.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include "struct.h"

void starter(Node *program){
     if(program == NULL ){
        return;
    }

}